const functions = require('firebase-functions');
const admin = require('firebase-admin');
const express = require('express');
const cors = require('cors');
const app = express();

// Initialize Firebase Admin SDK
var serviceAccount = require("./permissions.json");
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://restapi.firebase.com" // Make sure to replace this with your Firestore URL
});
const db = admin.firestore();

// Middleware
app.use(cors({ origin: true }));

// Routes
app.get('/hello-world', (req, res) => {
  return res.status(200).send('Hello World!');
});

// Create
// Post
app.post('/api/create', (req, res) => {
  (async () => {
    try {
      await db.collection('products').doc('/' + req.body.id + '').set({
        name: req.body.name,
        description: req.body.description,
        price: req.body.price,
      });
      return res.status(200).send();
    } catch (error) {
      console.log(error);
      return res.status(500).send(error);
    }
  })();

});

// Read
// Get using through ID
app.get('/api/read/:id', (req, res) => {
    (async () => {
      try {
        const documnet = db.collection('products').doc(req.params.id);
        let product = await documnet.get();
        let responce = product.data();
        return res.status(200).send(responce);
      } catch (error) {
        console.log(error);
        return res.status(500).send(error);
      }
    })();
  });


//   Get All the collection 
app.get('/api/products', (req, res) => {
    (async () => {
      try {
        const documnet =await db.collection('products').get();
        return res.status(200).send(documnet.data());
      } catch (error) {
        console.log(error);
        return res.status(500).send(error);
      }
    })();
  });

// ... Define other routes for Read, Update, Delete as needed ...

// Export the Express app as a Firebase Cloud Function
exports.app = functions.region('us-central1').https.onRequest(app);
